package com.shinyhut.vernacular.protocol.messages;

public enum SecurityType {

    INVALID,
    NONE,
    VNC
}
